#!/usr/bin/bash

cd kicad-source-mirror-4.0.7/build
sudo make uninstall
cd ../../
