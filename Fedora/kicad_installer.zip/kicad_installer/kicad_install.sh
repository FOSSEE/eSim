#!/usr/bin/bash

sudo dnf install -y unzip
sudo dnf install dnf-plugins-core
sudo dnf builddep -y kicad
sudo dnf install -y breezy
sudo dnf install -y patch
sudo dnf install -y openssl openssl-devel
if [ ! -f .config/breezy/breezy.conf ]; then
    bzr whoami "dummyname dummy@dummmy.com"
    del_bzr=true
fi
wget https://github.com/KiCad/kicad-source-mirror/archive/refs/tags/4.0.7.zip
unzip 4.0.7.zip
patch -u kicad-source-mirror-4.0.7/CMakeLists.txt -i CMakeLists.txt.patch
patch -u kicad-source-mirror-4.0.7/CMakeModules/CheckCXXSymbolExists.cmake -i CheckCXXSymbolExists.cmake.patch
patch -u kicad-source-mirror-4.0.7/cvpcb/class_DisplayFootprintsFrame.cpp -i class_DisplayFootprintsFrame.cpp.patch
patch -u kicad-source-mirror-4.0.7/cvpcb/class_DisplayFootprintsFrame.h -i class_DisplayFootprintsFrame.h.patch
cd kicad-source-mirror-4.0.7
mkdir build
cd build
cmake ../
make
sudo make install
cd ../../

if [ "$del_bzr" = true ]; then
    rm -fr .config/breezy/breezy.conf
fi
