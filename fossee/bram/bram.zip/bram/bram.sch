EESchema Schematic File Version 2
LIBS:adc-dac
LIBS:memory
LIBS:xilinx
LIBS:microcontrollers
LIBS:dsp
LIBS:microchip
LIBS:analog_switches
LIBS:motorola
LIBS:texas
LIBS:intel
LIBS:audio
LIBS:interface
LIBS:digital-audio
LIBS:philips
LIBS:display
LIBS:cypress
LIBS:siliconi
LIBS:opto
LIBS:atmel
LIBS:contrib
LIBS:power
LIBS:eSim_Plot
LIBS:transistors
LIBS:conn
LIBS:eSim_User
LIBS:regul
LIBS:74xx
LIBS:cmos4000
LIBS:eSim_Analog
LIBS:eSim_Devices
LIBS:eSim_Digital
LIBS:eSim_Hybrid
LIBS:eSim_Miscellaneous
LIBS:eSim_Power
LIBS:eSim_Sources
LIBS:eSim_Subckt
LIBS:eSim_Nghdl
LIBS:eSim_Ngveri
LIBS:eSim_SKY130
LIBS:eSim_SKY130_Subckts
LIBS:bram-cache
EELAYER 25 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L pulse v1
U 1 1 69A7BAF7
P 2650 2350
F 0 "v1" H 2450 2450 60  0000 C CNN
F 1 "pulse" H 2450 2300 60  0000 C CNN
F 2 "R1" H 2350 2350 60  0000 C CNN
F 3 "" H 2650 2350 60  0000 C CNN
	1    2650 2350
	0    1    1    0   
$EndComp
$Comp
L pulse v2
U 1 1 69A7BB5C
P 2650 2700
F 0 "v2" H 2450 2800 60  0000 C CNN
F 1 "pulse" H 2450 2650 60  0000 C CNN
F 2 "R1" H 2350 2700 60  0000 C CNN
F 3 "" H 2650 2700 60  0000 C CNN
	1    2650 2700
	0    1    1    0   
$EndComp
$Comp
L adc_bridge_4 U18
U 1 1 69A7C3BB
P 4750 3350
F 0 "U18" H 4750 3350 60  0000 C CNN
F 1 "adc_bridge_4" H 4750 3650 60  0000 C CNN
F 2 "" H 4750 3350 60  0000 C CNN
F 3 "" H 4750 3350 60  0000 C CNN
	1    4750 3350
	1    0    0    -1  
$EndComp
$Comp
L adc_bridge_8 U19
U 1 1 69A7C41C
P 4750 3600
F 0 "U19" H 4750 3600 60  0000 C CNN
F 1 "adc_bridge_8" H 4750 3750 60  0000 C CNN
F 2 "" H 4750 3600 60  0000 C CNN
F 3 "" H 4750 3600 60  0000 C CNN
	1    4750 3600
	1    0    0    -1  
$EndComp
$Comp
L adc_bridge_2 U17
U 1 1 69A7C477
P 4750 3000
F 0 "U17" H 4750 3000 60  0000 C CNN
F 1 "adc_bridge_2" H 4750 3150 60  0000 C CNN
F 2 "" H 4750 3000 60  0000 C CNN
F 3 "" H 4750 3000 60  0000 C CNN
	1    4750 3000
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR1
U 1 1 69A7D7E4
P 1800 2350
F 0 "#PWR1" H 1800 2100 50  0001 C CNN
F 1 "GND" H 1800 2200 50  0000 C CNN
F 2 "" H 1800 2350 50  0001 C CNN
F 3 "" H 1800 2350 50  0001 C CNN
	1    1800 2350
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR2
U 1 1 69A7D81C
P 2200 2700
F 0 "#PWR2" H 2200 2450 50  0001 C CNN
F 1 "GND" H 2200 2550 50  0000 C CNN
F 2 "" H 2200 2700 50  0001 C CNN
F 3 "" H 2200 2700 50  0001 C CNN
	1    2200 2700
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR3
U 1 1 69A7D854
P 2200 3250
F 0 "#PWR3" H 2200 3000 50  0001 C CNN
F 1 "GND" H 2200 3100 50  0000 C CNN
F 2 "" H 2200 3250 50  0001 C CNN
F 3 "" H 2200 3250 50  0001 C CNN
	1    2200 3250
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR4
U 1 1 69A7D88C
P 2200 3600
F 0 "#PWR4" H 2200 3350 50  0001 C CNN
F 1 "GND" H 2200 3450 50  0000 C CNN
F 2 "" H 2200 3600 50  0001 C CNN
F 3 "" H 2200 3600 50  0001 C CNN
	1    2200 3600
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR5
U 1 1 69A7D8C4
P 2200 3950
F 0 "#PWR5" H 2200 3700 50  0001 C CNN
F 1 "GND" H 2200 3800 50  0000 C CNN
F 2 "" H 2200 3950 50  0001 C CNN
F 3 "" H 2200 3950 50  0001 C CNN
	1    2200 3950
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR6
U 1 1 69A7D8FC
P 2200 4300
F 0 "#PWR6" H 2200 4050 50  0001 C CNN
F 1 "GND" H 2200 4150 50  0000 C CNN
F 2 "" H 2200 4300 50  0001 C CNN
F 3 "" H 2200 4300 50  0001 C CNN
	1    2200 4300
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR7
U 1 1 69A7DD36
P 2200 5100
F 0 "#PWR7" H 2200 4850 50  0001 C CNN
F 1 "GND" H 2200 4950 50  0000 C CNN
F 2 "" H 2200 5100 50  0001 C CNN
F 3 "" H 2200 5100 50  0001 C CNN
	1    2200 5100
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR8
U 1 1 69A7DD6E
P 2200 5450
F 0 "#PWR8" H 2200 5200 50  0001 C CNN
F 1 "GND" H 2200 5300 50  0000 C CNN
F 2 "" H 2200 5450 50  0001 C CNN
F 3 "" H 2200 5450 50  0001 C CNN
	1    2200 5450
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR9
U 1 1 69A7DDA6
P 2200 5800
F 0 "#PWR9" H 2200 5550 50  0001 C CNN
F 1 "GND" H 2200 5650 50  0000 C CNN
F 2 "" H 2200 5800 50  0001 C CNN
F 3 "" H 2200 5800 50  0001 C CNN
	1    2200 5800
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR10
U 1 1 69A7E300
P 2200 6150
F 0 "#PWR10" H 2200 5900 50  0001 C CNN
F 1 "GND" H 2200 6000 50  0000 C CNN
F 2 "" H 2200 6150 50  0001 C CNN
F 3 "" H 2200 6150 50  0001 C CNN
	1    2200 6150
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR11
U 1 1 69A7E338
P 2200 6500
F 0 "#PWR11" H 2200 6250 50  0001 C CNN
F 1 "GND" H 2200 6350 50  0000 C CNN
F 2 "" H 2200 6500 50  0001 C CNN
F 3 "" H 2200 6500 50  0001 C CNN
	1    2200 6500
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR12
U 1 1 69A7E370
P 2200 6850
F 0 "#PWR12" H 2200 6600 50  0001 C CNN
F 1 "GND" H 2200 6700 50  0000 C CNN
F 2 "" H 2200 6850 50  0001 C CNN
F 3 "" H 2200 6850 50  0001 C CNN
	1    2200 6850
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR13
U 1 1 69A7E3A8
P 2200 7200
F 0 "#PWR13" H 2200 6950 50  0001 C CNN
F 1 "GND" H 2200 7050 50  0000 C CNN
F 2 "" H 2200 7200 50  0001 C CNN
F 3 "" H 2200 7200 50  0001 C CNN
	1    2200 7200
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR14
U 1 1 69A7E3E0
P 2200 7550
F 0 "#PWR14" H 2200 7300 50  0001 C CNN
F 1 "GND" H 2200 7400 50  0000 C CNN
F 2 "" H 2200 7550 50  0001 C CNN
F 3 "" H 2200 7550 50  0001 C CNN
	1    2200 7550
	1    0    0    -1  
$EndComp
$Comp
L PWR_FLAG #FLG1
U 1 1 69A7EAD7
P 2050 2150
F 0 "#FLG1" H 2050 2225 50  0001 C CNN
F 1 "PWR_FLAG" H 2050 2300 50  0000 C CNN
F 2 "" H 2050 2150 50  0001 C CNN
F 3 "" H 2050 2150 50  0001 C CNN
	1    2050 2150
	1    0    0    -1  
$EndComp
Text GLabel 4100 2350 1    60   Input ~ 0
clk0
Text GLabel 4050 2700 1    60   Input ~ 0
we0
Text GLabel 4050 3150 1    60   Input ~ 0
addr3
Text GLabel 4150 3250 1    60   Input ~ 0
adr2
Text GLabel 4050 3350 1    60   Input ~ 0
adr1
Text GLabel 4100 3400 1    60   Input ~ 0
adr0
Text GLabel 3950 3550 1    60   Input ~ 0
d7
Text GLabel 4050 3650 1    60   Input ~ 0
d6
Text GLabel 4050 3750 1    60   Input ~ 0
d5
Text GLabel 4000 3850 1    60   Input ~ 0
d4
Text GLabel 4050 3950 1    60   Input ~ 0
d3
Text GLabel 4100 4050 1    60   Input ~ 0
d2
Text GLabel 4100 4150 1    60   Input ~ 0
d1
Text GLabel 4050 4250 1    60   Input ~ 0
d0
$Comp
L plot_v1 U10
U 1 1 69A7EFC8
P 3450 2450
F 0 "U10" H 3450 2950 60  0000 C CNN
F 1 "plot_v1" H 3650 2800 60  0000 C CNN
F 2 "" H 3450 2450 60  0000 C CNN
F 3 "" H 3450 2450 60  0000 C CNN
	1    3450 2450
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U15
U 1 1 69A7F023
P 3550 2800
F 0 "U15" H 3550 3300 60  0000 C CNN
F 1 "plot_v1" H 3750 3150 60  0000 C CNN
F 2 "" H 3550 2800 60  0000 C CNN
F 3 "" H 3550 2800 60  0000 C CNN
	1    3550 2800
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U6
U 1 1 69A7F070
P 3200 3300
F 0 "U6" H 3200 3800 60  0000 C CNN
F 1 "plot_v1" H 3400 3650 60  0000 C CNN
F 2 "" H 3200 3300 60  0000 C CNN
F 3 "" H 3200 3300 60  0000 C CNN
	1    3200 3300
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U13
U 1 1 69A7F0CD
P 3500 3400
F 0 "U13" H 3500 3900 60  0000 C CNN
F 1 "plot_v1" H 3700 3750 60  0000 C CNN
F 2 "" H 3500 3400 60  0000 C CNN
F 3 "" H 3500 3400 60  0000 C CNN
	1    3500 3400
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U16
U 1 1 69A7F126
P 3600 3500
F 0 "U16" H 3600 4000 60  0000 C CNN
F 1 "plot_v1" H 3800 3850 60  0000 C CNN
F 2 "" H 3600 3500 60  0000 C CNN
F 3 "" H 3600 3500 60  0000 C CNN
	1    3600 3500
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U8
U 1 1 69A7F16F
P 3300 4000
F 0 "U8" H 3300 4500 60  0000 C CNN
F 1 "plot_v1" H 3500 4350 60  0000 C CNN
F 2 "" H 3300 4000 60  0000 C CNN
F 3 "" H 3300 4000 60  0000 C CNN
	1    3300 4000
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U1
U 1 1 69A7F1D4
P 3000 4300
F 0 "U1" H 3000 4800 60  0000 C CNN
F 1 "plot_v1" H 3200 4650 60  0000 C CNN
F 2 "" H 3000 4300 60  0000 C CNN
F 3 "" H 3000 4300 60  0000 C CNN
	1    3000 4300
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U3
U 1 1 69A7F239
P 3150 4450
F 0 "U3" H 3150 4950 60  0000 C CNN
F 1 "plot_v1" H 3350 4800 60  0000 C CNN
F 2 "" H 3150 4450 60  0000 C CNN
F 3 "" H 3150 4450 60  0000 C CNN
	1    3150 4450
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U11
U 1 1 69A7F28C
P 3450 4500
F 0 "U11" H 3450 5000 60  0000 C CNN
F 1 "plot_v1" H 3650 4850 60  0000 C CNN
F 2 "" H 3450 4500 60  0000 C CNN
F 3 "" H 3450 4500 60  0000 C CNN
	1    3450 4500
	1    0    0    -1  
$EndComp
Wire Wire Line
	3100 2350 4150 2350
Wire Wire Line
	4150 2350 4150 2950
Wire Wire Line
	3100 2700 4100 2700
Wire Wire Line
	4100 2700 4100 3050
Wire Wire Line
	4100 3050 4150 3050
Wire Wire Line
	3100 3250 3150 3250
Wire Wire Line
	3150 3250 3150 3150
Wire Wire Line
	3150 3150 4200 3150
Wire Wire Line
	3100 3600 3100 3350
Wire Wire Line
	3100 3350 3350 3350
Wire Wire Line
	3350 3350 3350 3250
Wire Wire Line
	3350 3250 4200 3250
Wire Wire Line
	3100 3950 3450 3950
Wire Wire Line
	3450 3950 3450 3350
Wire Wire Line
	3450 3350 4200 3350
Wire Wire Line
	3100 4000 3100 4300
Wire Wire Line
	3500 4000 3100 4000
Wire Wire Line
	3500 3400 3500 4000
Wire Wire Line
	3500 3400 4200 3400
Wire Wire Line
	4200 3400 4200 3450
Wire Wire Line
	3100 5100 3100 4400
Wire Wire Line
	3100 4400 3250 4400
Wire Wire Line
	3250 4400 3250 4100
Wire Wire Line
	3250 4100 3550 4100
Wire Wire Line
	3550 4100 3550 3550
Wire Wire Line
	3550 3550 4150 3550
Wire Wire Line
	3100 5450 3150 5450
Wire Wire Line
	3150 5450 3150 4450
Wire Wire Line
	3150 4450 3300 4450
Wire Wire Line
	3300 4450 3300 4150
Wire Wire Line
	3300 4150 3600 4150
Wire Wire Line
	3600 4150 3600 3650
Wire Wire Line
	3600 3650 4150 3650
Wire Wire Line
	3100 5800 3650 5800
Wire Wire Line
	3650 5800 3650 3750
Wire Wire Line
	3650 3750 4150 3750
Wire Wire Line
	3100 6150 3700 6150
Wire Wire Line
	3700 6150 3700 3850
Wire Wire Line
	3700 3850 4150 3850
Wire Wire Line
	3100 6500 3750 6500
Wire Wire Line
	3750 6500 3750 3950
Wire Wire Line
	3750 3950 4150 3950
Wire Wire Line
	3100 6850 3800 6850
Wire Wire Line
	3800 6850 3800 4050
Wire Wire Line
	3800 4050 4150 4050
Wire Wire Line
	3100 7200 3850 7200
Wire Wire Line
	3850 7200 3850 4150
Wire Wire Line
	3850 4150 4150 4150
Wire Wire Line
	3100 7550 3950 7550
Wire Wire Line
	3950 7550 3950 4250
Wire Wire Line
	3950 4250 4150 4250
Wire Wire Line
	1800 2350 2200 2350
Wire Wire Line
	2050 2150 2050 2350
Connection ~ 2050 2350
Wire Wire Line
	3450 2250 3450 2350
Connection ~ 3450 2350
Wire Wire Line
	3550 2600 3550 2700
Connection ~ 3550 2700
Wire Wire Line
	3200 3100 3200 3150
Connection ~ 3200 3150
Wire Wire Line
	3500 3200 3500 3250
Connection ~ 3500 3250
Wire Wire Line
	3600 3300 3600 3350
Connection ~ 3600 3350
Wire Wire Line
	3300 3800 3500 3800
Wire Wire Line
	3500 3800 3500 3750
Connection ~ 3500 3750
Wire Wire Line
	3000 4100 3100 4100
Connection ~ 3100 4100
Wire Wire Line
	3150 4250 3250 4250
Connection ~ 3250 4250
Wire Wire Line
	3300 4300 3450 4300
Connection ~ 3300 4300
$Comp
L plot_v1 U9
U 1 1 69A7FC4E
P 3400 5900
F 0 "U9" H 3400 6400 60  0000 C CNN
F 1 "plot_v1" H 3600 6250 60  0000 C CNN
F 2 "" H 3400 5900 60  0000 C CNN
F 3 "" H 3400 5900 60  0000 C CNN
	1    3400 5900
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U5
U 1 1 69A7FCAD
P 3150 6300
F 0 "U5" H 3150 6800 60  0000 C CNN
F 1 "plot_v1" H 3350 6650 60  0000 C CNN
F 2 "" H 3150 6300 60  0000 C CNN
F 3 "" H 3150 6300 60  0000 C CNN
	1    3150 6300
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U12
U 1 1 69A7FD0A
P 3450 6600
F 0 "U12" H 3450 7100 60  0000 C CNN
F 1 "plot_v1" H 3650 6950 60  0000 C CNN
F 2 "" H 3450 6600 60  0000 C CNN
F 3 "" H 3450 6600 60  0000 C CNN
	1    3450 6600
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U2
U 1 1 69A7FD6B
P 3100 6950
F 0 "U2" H 3100 7450 60  0000 C CNN
F 1 "plot_v1" H 3300 7300 60  0000 C CNN
F 2 "" H 3100 6950 60  0000 C CNN
F 3 "" H 3100 6950 60  0000 C CNN
	1    3100 6950
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U14
U 1 1 69A7FE01
P 3500 7300
F 0 "U14" H 3500 7800 60  0000 C CNN
F 1 "plot_v1" H 3700 7650 60  0000 C CNN
F 2 "" H 3500 7300 60  0000 C CNN
F 3 "" H 3500 7300 60  0000 C CNN
	1    3500 7300
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U7
U 1 1 69A7FE66
P 3200 7700
F 0 "U7" H 3200 8200 60  0000 C CNN
F 1 "plot_v1" H 3400 8050 60  0000 C CNN
F 2 "" H 3200 7700 60  0000 C CNN
F 3 "" H 3200 7700 60  0000 C CNN
	1    3200 7700
	1    0    0    -1  
$EndComp
Wire Wire Line
	3400 5700 3400 5800
Connection ~ 3400 5800
Wire Wire Line
	3150 6100 3150 6150
Connection ~ 3150 6150
Wire Wire Line
	3450 6400 3450 6500
Connection ~ 3450 6500
Wire Wire Line
	3100 6750 3100 6850
Wire Wire Line
	3500 7100 3500 7200
Connection ~ 3500 7200
Wire Wire Line
	3200 7500 3200 7550
Connection ~ 3200 7550
$Comp
L dac_bridge_8 U20
U 1 1 69A81313
P 7300 3000
F 0 "U20" H 7300 3000 60  0000 C CNN
F 1 "dac_bridge_8" H 7300 3150 60  0000 C CNN
F 2 "" H 7300 3000 60  0000 C CNN
F 3 "" H 7300 3000 60  0000 C CNN
	1    7300 3000
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U21
U 1 1 69A81386
P 9550 1500
F 0 "U21" H 9550 2000 60  0000 C CNN
F 1 "plot_v1" H 9750 1850 60  0000 C CNN
F 2 "" H 9550 1500 60  0000 C CNN
F 3 "" H 9550 1500 60  0000 C CNN
	1    9550 1500
	0    1    1    0   
$EndComp
$Comp
L plot_v1 U22
U 1 1 69A813F7
P 9600 1800
F 0 "U22" H 9600 2300 60  0000 C CNN
F 1 "plot_v1" H 9800 2150 60  0000 C CNN
F 2 "" H 9600 1800 60  0000 C CNN
F 3 "" H 9600 1800 60  0000 C CNN
	1    9600 1800
	0    1    1    0   
$EndComp
$Comp
L plot_v1 U23
U 1 1 69A814EE
P 9600 2050
F 0 "U23" H 9600 2550 60  0000 C CNN
F 1 "plot_v1" H 9800 2400 60  0000 C CNN
F 2 "" H 9600 2050 60  0000 C CNN
F 3 "" H 9600 2050 60  0000 C CNN
	1    9600 2050
	0    1    1    0   
$EndComp
$Comp
L plot_v1 U24
U 1 1 69A814F5
P 9650 2350
F 0 "U24" H 9650 2850 60  0000 C CNN
F 1 "plot_v1" H 9850 2700 60  0000 C CNN
F 2 "" H 9650 2350 60  0000 C CNN
F 3 "" H 9650 2350 60  0000 C CNN
	1    9650 2350
	0    1    1    0   
$EndComp
$Comp
L plot_v1 U25
U 1 1 69A815F4
P 9650 2750
F 0 "U25" H 9650 3250 60  0000 C CNN
F 1 "plot_v1" H 9850 3100 60  0000 C CNN
F 2 "" H 9650 2750 60  0000 C CNN
F 3 "" H 9650 2750 60  0000 C CNN
	1    9650 2750
	0    1    1    0   
$EndComp
$Comp
L plot_v1 U26
U 1 1 69A815FB
P 9700 3050
F 0 "U26" H 9700 3550 60  0000 C CNN
F 1 "plot_v1" H 9900 3400 60  0000 C CNN
F 2 "" H 9700 3050 60  0000 C CNN
F 3 "" H 9700 3050 60  0000 C CNN
	1    9700 3050
	0    1    1    0   
$EndComp
$Comp
L plot_v1 U27
U 1 1 69A81602
P 9700 3300
F 0 "U27" H 9700 3800 60  0000 C CNN
F 1 "plot_v1" H 9900 3650 60  0000 C CNN
F 2 "" H 9700 3300 60  0000 C CNN
F 3 "" H 9700 3300 60  0000 C CNN
	1    9700 3300
	0    1    1    0   
$EndComp
$Comp
L plot_v1 U28
U 1 1 69A81609
P 9750 3600
F 0 "U28" H 9750 4100 60  0000 C CNN
F 1 "plot_v1" H 9950 3950 60  0000 C CNN
F 2 "" H 9750 3600 60  0000 C CNN
F 3 "" H 9750 3600 60  0000 C CNN
	1    9750 3600
	0    1    1    0   
$EndComp
Wire Wire Line
	9750 1500 7850 1500
Wire Wire Line
	7850 1500 7850 2950
Wire Wire Line
	9800 1800 7900 1800
Wire Wire Line
	7900 1800 7900 3050
Wire Wire Line
	7900 3050 7850 3050
Wire Wire Line
	9800 2050 7950 2050
Wire Wire Line
	7950 2050 7950 3150
Wire Wire Line
	7950 3150 7850 3150
Wire Wire Line
	7850 3250 8000 3250
Wire Wire Line
	8000 3250 8000 2350
Wire Wire Line
	8000 2350 9850 2350
Wire Wire Line
	7850 3350 8050 3350
Wire Wire Line
	8050 3350 8050 2750
Wire Wire Line
	8050 2750 9850 2750
Wire Wire Line
	9900 3050 8100 3050
Wire Wire Line
	8100 3050 8100 3450
Wire Wire Line
	8100 3450 7850 3450
Wire Wire Line
	7850 3550 8550 3550
Wire Wire Line
	8550 3550 8550 3300
Wire Wire Line
	8550 3300 9900 3300
Wire Wire Line
	7850 3650 9950 3650
Wire Wire Line
	9950 3650 9950 3600
Text GLabel 8750 1500 1    60   Input ~ 0
q7
Text GLabel 8800 1800 1    60   Input ~ 0
q6
Text GLabel 8850 2050 1    60   Input ~ 0
q5
Text GLabel 9250 2350 1    60   Input ~ 0
q4
Text GLabel 9250 2750 1    60   Input ~ 0
q3
Text GLabel 9550 3050 1    60   Input ~ 0
q2
Text GLabel 8950 3300 1    60   Input ~ 0
q1
Text GLabel 9500 3650 1    60   Input ~ 0
q0
$Comp
L pulse v3
U 1 1 69A7C8E4
P 2650 3250
F 0 "v3" H 2450 3350 60  0000 C CNN
F 1 "pulse" H 2450 3200 60  0000 C CNN
F 2 "R1" H 2350 3250 60  0000 C CNN
F 3 "" H 2650 3250 60  0000 C CNN
	1    2650 3250
	0    1    1    0   
$EndComp
$Comp
L pulse v4
U 1 1 69A7C8EB
P 2650 3600
F 0 "v4" H 2450 3700 60  0000 C CNN
F 1 "pulse" H 2450 3550 60  0000 C CNN
F 2 "R1" H 2350 3600 60  0000 C CNN
F 3 "" H 2650 3600 60  0000 C CNN
	1    2650 3600
	0    1    1    0   
$EndComp
$Comp
L pulse v5
U 1 1 69A7CC22
P 2650 3950
F 0 "v5" H 2450 4050 60  0000 C CNN
F 1 "pulse" H 2450 3900 60  0000 C CNN
F 2 "R1" H 2350 3950 60  0000 C CNN
F 3 "" H 2650 3950 60  0000 C CNN
	1    2650 3950
	0    1    1    0   
$EndComp
$Comp
L pulse v6
U 1 1 69A7CC29
P 2650 4300
F 0 "v6" H 2450 4400 60  0000 C CNN
F 1 "pulse" H 2450 4250 60  0000 C CNN
F 2 "R1" H 2350 4300 60  0000 C CNN
F 3 "" H 2650 4300 60  0000 C CNN
	1    2650 4300
	0    1    1    0   
$EndComp
$Comp
L pulse v7
U 1 1 69A7CCAE
P 2650 5100
F 0 "v7" H 2450 5200 60  0000 C CNN
F 1 "pulse" H 2450 5050 60  0000 C CNN
F 2 "R1" H 2350 5100 60  0000 C CNN
F 3 "" H 2650 5100 60  0000 C CNN
	1    2650 5100
	0    1    1    0   
$EndComp
$Comp
L pulse v8
U 1 1 69A7CCB5
P 2650 5450
F 0 "v8" H 2450 5550 60  0000 C CNN
F 1 "pulse" H 2450 5400 60  0000 C CNN
F 2 "R1" H 2350 5450 60  0000 C CNN
F 3 "" H 2650 5450 60  0000 C CNN
	1    2650 5450
	0    1    1    0   
$EndComp
$Comp
L pulse v9
U 1 1 69A7CD3C
P 2650 5800
F 0 "v9" H 2450 5900 60  0000 C CNN
F 1 "pulse" H 2450 5750 60  0000 C CNN
F 2 "R1" H 2350 5800 60  0000 C CNN
F 3 "" H 2650 5800 60  0000 C CNN
	1    2650 5800
	0    1    1    0   
$EndComp
$Comp
L pulse v10
U 1 1 69A7CD43
P 2650 6150
F 0 "v10" H 2450 6250 60  0000 C CNN
F 1 "pulse" H 2450 6100 60  0000 C CNN
F 2 "R1" H 2350 6150 60  0000 C CNN
F 3 "" H 2650 6150 60  0000 C CNN
	1    2650 6150
	0    1    1    0   
$EndComp
$Comp
L pulse v11
U 1 1 69A7CE14
P 2650 6500
F 0 "v11" H 2450 6600 60  0000 C CNN
F 1 "pulse" H 2450 6450 60  0000 C CNN
F 2 "R1" H 2350 6500 60  0000 C CNN
F 3 "" H 2650 6500 60  0000 C CNN
	1    2650 6500
	0    1    1    0   
$EndComp
$Comp
L pulse v12
U 1 1 69A7CE1B
P 2650 6850
F 0 "v12" H 2450 6950 60  0000 C CNN
F 1 "pulse" H 2450 6800 60  0000 C CNN
F 2 "R1" H 2350 6850 60  0000 C CNN
F 3 "" H 2650 6850 60  0000 C CNN
	1    2650 6850
	0    1    1    0   
$EndComp
$Comp
L pulse v13
U 1 1 69A7D4A2
P 2650 7200
F 0 "v13" H 2450 7300 60  0000 C CNN
F 1 "pulse" H 2450 7150 60  0000 C CNN
F 2 "R1" H 2350 7200 60  0000 C CNN
F 3 "" H 2650 7200 60  0000 C CNN
	1    2650 7200
	0    1    1    0   
$EndComp
$Comp
L pulse v14
U 1 1 69A7D4A9
P 2650 7550
F 0 "v14" H 2450 7650 60  0000 C CNN
F 1 "pulse" H 2450 7500 60  0000 C CNN
F 2 "R1" H 2350 7550 60  0000 C CNN
F 3 "" H 2650 7550 60  0000 C CNN
	1    2650 7550
	0    1    1    0   
$EndComp
$Comp
L bram U?
U 1 1 69A7C71E
P 3150 4850
F 0 "U?" H 6000 6650 60  0000 C CNN
F 1 "bram" H 6000 6850 60  0000 C CNN
F 2 "" H 6000 6800 60  0000 C CNN
F 3 "" H 6000 6800 60  0000 C CNN
	1    3150 4850
	1    0    0    -1  
$EndComp
$EndSCHEMATC
